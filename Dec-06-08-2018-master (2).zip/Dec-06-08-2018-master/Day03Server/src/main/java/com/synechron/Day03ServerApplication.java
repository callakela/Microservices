package com.synechron;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class Day03ServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(Day03ServerApplication.class, args);
	}
}
