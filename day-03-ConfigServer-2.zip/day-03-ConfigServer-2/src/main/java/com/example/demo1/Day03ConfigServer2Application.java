package com.example.demo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.cloud.config.server.EnableConfigServer;

@SpringBootApplication
@EnableConfigServer
public class Day03ConfigServer2Application {

	public static void main(String[] args) {
		SpringApplication.run(Day03ConfigServer2Application.class, args);
	}
}
