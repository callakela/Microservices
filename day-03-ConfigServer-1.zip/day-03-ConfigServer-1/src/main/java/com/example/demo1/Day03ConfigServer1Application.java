package com.example.demo1;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
@EnableC
public class Day03ConfigServer1Application {

	public static void main(String[] args) {
		SpringApplication.run(Day03ConfigServer1Application.class, args);
	}
}
